import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class BasicAuthenticationTest {

        @BeforeClass
        public static void setup() {
            RestAssured.baseURI = "https://practicetestautomation.com";
        }

        @Test
        public void testBasicAuth() {
            String username = "student";
            String password = "Password123";
            Response response = RestAssured
                    .given()
                    .auth()
                    .basic(username, password) // Using basic authentication
                    .when()
                    .get("/practice-test-login");
            Assert.assertEquals(200, response.statusCode());
        }

}

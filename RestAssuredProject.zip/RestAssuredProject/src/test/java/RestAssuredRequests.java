import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import static io.restassured.RestAssured.given;

public class RestAssuredRequests {

    @BeforeClass
    public static void setup() {
        RestAssured.baseURI = "https://reqres.in/";
    }

    @Test
    public void getRequest() {
        String userId = "2";
        Response response = given().pathParam("userId", userId).
                contentType(ContentType.JSON)
                .when()
                .get("api/users/{userId}")
                .then()
                .extract().response();

        Assert.assertEquals(200, response.statusCode());
    }

    @Test
    public void getRequestWithQueryParam() {
        Response response = given()
                .contentType(ContentType.JSON)
                .param("page", "2")
                .when()
                .get("/api/users")
                .then()
                .extract().response();
        Assert.assertEquals(200, response.statusCode());
        Assert.assertEquals("2", response.jsonPath().getString("page"));
    }
    
    @Test
    public void postRequest() {
        String requestBody = "{\n" +
                "    \"name\": \"Arjun\",\n" +
                "    \"role\": \"Test Lead\"\n" +
                "}" ;

        Response response = given()
                .header("Content-type", "application/json")
                .and()
                .body(requestBody)
                .when()
                .post("/api/users")
                .then()
                .extract().response();

        Assert.assertEquals(201, response.statusCode());
        Assert.assertEquals("Arjun", response.jsonPath().getString("name"));
        Assert.assertEquals("Test Lead", response.jsonPath().getString("role"));
    }

    @Test
    public void putRequest() {
        String requestBody = "{\n" +
                "    \"name\": \"Arjun\",\n" +
                "    \"role\": \"Sr.Test Analyst\"\n" +
                "}";
        Response response = given()
                .header("Content-type", "application/json")
                .and()
                .body(requestBody)
                .when()
                .put("/api/users/1")
                .then()
                .extract().response();
        System.out.println("ResponseBody" + response.asString());

        Assert.assertEquals(200, response.statusCode());
        Assert.assertEquals("Sr.Test Analyst", response.jsonPath().getString("role"));
    }

        @Test
        public void deleteRequest() {
            Response response = given()
                    .header("Content-type", "application/json")
                    .when()
                    .delete("/api/users/2")
                    .then()
                    .extract().response();
            Assert.assertEquals(204, response.statusCode());

        }
}
package stepDefinitions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class StepDefinitions {

    private static ChromeDriver driver;

    @Given("I am on the login page")
    public void navigate_to_base_url() {
        System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://practicetestautomation.com/practice-test-login/");
    }

    @When("I enter valid credentials")
    public void enter_valid_credentials() {
        WebElement usernameInput = driver.findElement(By.id("username"));
        WebElement passwordInput = driver.findElement(By.id("password"));
        usernameInput.sendKeys("student");
        passwordInput.sendKeys("Password123");
    }

    @And("I click the login button")
    public void clickOnSubmit() {
        WebElement submitButton = driver.findElement(By.id("submit"));
        submitButton.click();
    }

    @Then("I should be logged in successfully")
    public void successfulLogin() {
        WebElement welcomeMessage = driver.findElement(By.xpath("//h1[contains(text(), 'Logged In Successfully')]"));
        Assert.assertTrue(welcomeMessage.isDisplayed(), "Incorrect username/password, login failed!!");
    }
}

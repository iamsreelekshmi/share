package runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/features", // Path to your feature files
        glue = "stepDefinitions",                  // Package where your step definitions are located
        plugin = {"pretty", "html:target/cucumber-reports"} // Optional: Generate HTML reports
)
public class TestRunner extends AbstractTestNGCucumberTests {

}
